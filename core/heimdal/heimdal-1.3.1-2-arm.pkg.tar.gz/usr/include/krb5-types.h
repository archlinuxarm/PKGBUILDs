/* krb5-types.h -- this file was generated for armv5tel-unknown-linux-gnueabi by
                   $Id$ */

#ifndef __krb5_types_h__
#define __krb5_types_h__

#include <inttypes.h>
#include <sys/types.h>
#include <sys/bitypes.h>
#include <sys/socket.h>


typedef socklen_t krb5_socklen_t;
#include <unistd.h>
typedef ssize_t krb5_ssize_t;

#endif /* __krb5_types_h__ */
